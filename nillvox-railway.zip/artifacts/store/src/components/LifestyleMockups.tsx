/* ─────────────────────────────────────────────────────────────────────────
   Mockup 1 — Bundle Showcase
   "Everything you get for $9.99"
───────────────────────────────────────────────────────────────────────── */
export function PhoneMockup({ className = "" }: { className?: string }) {
  const features = [
    "48-page printable Standard PDF",
    "50-page interactive Premium PDF",
    "75 summer challenges + level system",
    "Weekly & monthly planning layouts",
    "Habit, fitness & finance tracker",
    "50 bucket list ideas with tracker",
    "30 motivational quotes",
    "Instant download — no subscription",
  ];

  return (
    <svg viewBox="0 0 520 580" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        <linearGradient id="bg1" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f0fdf9" />
          <stop offset="100%" stopColor="#e6f9f5" />
        </linearGradient>
        <linearGradient id="doc1" x1="0" y1="0" x2="0.4" y2="1">
          <stop offset="0%" stopColor="#14b8a6" />
          <stop offset="100%" stopColor="#0e8f80" />
        </linearGradient>
        <linearGradient id="doc2" x1="0" y1="0" x2="0.4" y2="1">
          <stop offset="0%" stopColor="#FFB703" />
          <stop offset="100%" stopColor="#e09e00" />
        </linearGradient>
        <filter id="sh1">
          <feDropShadow dx="0" dy="8" stdDeviation="12" floodColor="#14b8a6" floodOpacity="0.22" />
        </filter>
        <filter id="sh2">
          <feDropShadow dx="0" dy="6" stdDeviation="10" floodColor="#FFB703" floodOpacity="0.2" />
        </filter>
      </defs>

      <rect width="520" height="580" fill="url(#bg1)" />

      {/* Soft circle deco */}
      <circle cx="430" cy="80" r="90" fill="#14b8a6" fillOpacity="0.07" />
      <circle cx="70" cy="500" r="100" fill="#FFB703" fillOpacity="0.07" />

      {/* Header */}
      <text x="260" y="44" textAnchor="middle" fontSize="11" fontWeight="700" fill="#14b8a6" letterSpacing="3" fontFamily="system-ui">WHAT YOU GET</text>
      <text x="260" y="72" textAnchor="middle" fontSize="22" fontWeight="900" fill="#0f2027" letterSpacing="-0.5" fontFamily="system-ui">Everything in one bundle</text>

      {/* Premium PDF doc (back, tilted) */}
      <g filter="url(#sh2)" transform="rotate(6, 330, 230)">
        <rect x="252" y="100" width="150" height="200" rx="10" fill="url(#doc2)" />
        <rect x="252" y="100" width="150" height="28" rx="10" fill="#FFB703" />
        <rect x="252" y="118" width="150" height="10" fill="#FFB703" />
        <text x="327" y="117" textAnchor="middle" fontSize="7.5" fontWeight="800" fill="rgba(255,255,255,0.85)" letterSpacing="1.5" fontFamily="system-ui">PREMIUM EDITION</text>
        <rect x="266" y="136" width="110" height="5" rx="2.5" fill="rgba(255,255,255,0.4)" />
        <rect x="266" y="148" width="90" height="5" rx="2.5" fill="rgba(255,255,255,0.3)" />
        <rect x="266" y="160" width="100" height="5" rx="2.5" fill="rgba(255,255,255,0.3)" />
        <text x="327" y="220" textAnchor="middle" fontSize="11" fontWeight="900" fill="rgba(255,255,255,0.9)" fontFamily="system-ui">INTERACTIVE</text>
        <text x="327" y="236" textAnchor="middle" fontSize="9" fill="rgba(255,255,255,0.7)" fontFamily="system-ui">50 pages · PDF</text>
        <rect x="284" y="270" width="86" height="22" rx="11" fill="rgba(255,255,255,0.2)" />
        <text x="327" y="285" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="white" fontFamily="system-ui">⭐ LEVEL SYSTEM</text>
      </g>

      {/* Standard PDF doc (front, slight tilt) */}
      <g filter="url(#sh1)" transform="rotate(-4, 190, 230)">
        <rect x="110" y="95" width="160" height="215" rx="10" fill="url(#doc1)" />
        <rect x="110" y="95" width="160" height="30" rx="10" fill="#0f9a8a" />
        <rect x="110" y="115" width="160" height="10" fill="#0f9a8a" />
        <text x="190" y="114" textAnchor="middle" fontSize="7.5" fontWeight="800" fill="rgba(255,255,255,0.85)" letterSpacing="1.5" fontFamily="system-ui">STANDARD EDITION</text>
        <rect x="124" y="134" width="120" height="5" rx="2.5" fill="rgba(255,255,255,0.4)" />
        <rect x="124" y="146" width="100" height="5" rx="2.5" fill="rgba(255,255,255,0.3)" />
        <rect x="124" y="158" width="110" height="5" rx="2.5" fill="rgba(255,255,255,0.3)" />
        <text x="190" y="222" textAnchor="middle" fontSize="11" fontWeight="900" fill="rgba(255,255,255,0.9)" fontFamily="system-ui">PRINTABLE</text>
        <text x="190" y="238" textAnchor="middle" fontSize="9" fill="rgba(255,255,255,0.7)" fontFamily="system-ui">48 pages · PDF</text>
        <rect x="144" y="274" width="92" height="22" rx="11" fill="rgba(255,255,255,0.2)" />
        <text x="190" y="289" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="white" fontFamily="system-ui">📥 INSTANT DL</text>
      </g>

      {/* Features checklist */}
      <rect x="28" y="342" width="464" height="180" rx="16" fill="white" fillOpacity="0.85" />
      <text x="260" y="366" textAnchor="middle" fontSize="10.5" fontWeight="700" fill="#14b8a6" letterSpacing="2" fontFamily="system-ui">INCLUDED IN YOUR BUNDLE</text>
      {features.map((f, i) => (
        <g key={i}>
          <circle cx={i < 4 ? 56 : 286} cy={387 + (i % 4) * 30} r="9" fill="#14b8a6" fillOpacity={i < 4 ? 1 : 0.9} />
          <text x={i < 4 ? 56 : 286} y={391 + (i % 4) * 30} textAnchor="middle" fontSize="10" fill="white" fontFamily="system-ui">✓</text>
          <text x={i < 4 ? 72 : 302} y={391 + (i % 4) * 30} fontSize="10.5" fill="#1e293b" fontFamily="system-ui" fontWeight="500">{f}</text>
        </g>
      ))}

      {/* Price tag */}
      <rect x="150" y="537" width="220" height="34" rx="17" fill="#14b8a6" />
      <text x="260" y="552" textAnchor="middle" fontSize="10" fill="rgba(255,255,255,0.7)" fontFamily="system-ui">All of this for just</text>
      <text x="260" y="566" textAnchor="middle" fontSize="13" fontWeight="900" fill="white" fontFamily="system-ui">$9.99 — One-time payment</text>
    </svg>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   Mockup 2 — Transformation: Before → After Summer
───────────────────────────────────────────────────────────────────────── */
export function NotebookMockup({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 520 580" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        <linearGradient id="bg2" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#fff9f0" />
          <stop offset="100%" stopColor="#fff4e6" />
        </linearGradient>
        <linearGradient id="beforeBg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f1f5f9" />
          <stop offset="100%" stopColor="#e2e8f0" />
        </linearGradient>
        <linearGradient id="afterBg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f0fdf4" />
          <stop offset="100%" stopColor="#dcfce7" />
        </linearGradient>
        <filter id="sh3">
          <feDropShadow dx="0" dy="5" stdDeviation="10" floodColor="#000" floodOpacity="0.08" />
        </filter>
      </defs>

      <rect width="520" height="580" fill="url(#bg2)" />
      <circle cx="260" cy="50" r="120" fill="#FFB703" fillOpacity="0.06" />

      {/* Header */}
      <text x="260" y="44" textAnchor="middle" fontSize="11" fontWeight="700" fill="#FFB703" letterSpacing="3" fontFamily="system-ui">THE TRANSFORMATION</text>
      <text x="260" y="72" textAnchor="middle" fontSize="21" fontWeight="900" fill="#0f2027" letterSpacing="-0.5" fontFamily="system-ui">Your Summer, Before &amp; After</text>

      {/* Arrow between panels */}
      <circle cx="260" cy="290" r="26" fill="#FFB703" />
      <text x="260" y="298" textAnchor="middle" fontSize="20" fontFamily="system-ui">→</text>

      {/* BEFORE panel */}
      <g filter="url(#sh3)">
        <rect x="20" y="100" width="212" height="370" rx="16" fill="url(#beforeBg)" />
        <rect x="20" y="100" width="212" height="38" rx="16" fill="#94a3b8" />
        <rect x="20" y="122" width="212" height="16" fill="#94a3b8" />
        <text x="126" y="124" textAnchor="middle" fontSize="11" fontWeight="800" fill="white" letterSpacing="1.5" fontFamily="system-ui">BEFORE</text>

        {/* Before items — scattered, stressful */}
        {[
          { emoji: "😴", label: "No routine", sub: "Waking up at noon" },
          { emoji: "📱", label: "Endless scrolling", sub: "4+ hours on phone" },
          { emoji: "😤", label: "No clear goals", sub: "\"I'll start Monday\"" },
          { emoji: "💸", label: "Overspending", sub: "No budget plan" },
          { emoji: "😶", label: "Low motivation", sub: "Summer passing by" },
        ].map((item, i) => (
          <g key={i}>
            <rect x="34" y={150 + i * 60} width="186" height="48" rx="10" fill="white" fillOpacity="0.6" />
            <text x="60" y={174 + i * 60} fontSize="18" fontFamily="system-ui">{item.emoji}</text>
            <text x="82" y={169 + i * 60} fontSize="10.5" fontWeight="700" fill="#475569" fontFamily="system-ui">{item.label}</text>
            <text x="82" y={183 + i * 60} fontSize="9.5" fill="#94a3b8" fontFamily="system-ui">{item.sub}</text>
            {/* X mark */}
            <circle cx="196" cy={174 + i * 60} r="10" fill="#fee2e2" />
            <text x="196" y="178.5" dy={i * 60} textAnchor="middle" fontSize="10" fill="#ef4444" fontFamily="system-ui">✕</text>
          </g>
        ))}
      </g>

      {/* AFTER panel */}
      <g filter="url(#sh3)">
        <rect x="288" y="100" width="212" height="370" rx="16" fill="url(#afterBg)" />
        <rect x="288" y="100" width="212" height="38" rx="16" fill="#14b8a6" />
        <rect x="288" y="122" width="212" height="16" fill="#14b8a6" />
        <text x="394" y="124" textAnchor="middle" fontSize="11" fontWeight="800" fill="white" letterSpacing="1.5" fontFamily="system-ui">AFTER ☀️</text>

        {/* After items — wins, achievements */}
        {[
          { emoji: "🌅", label: "6am wake-up", sub: "Consistent morning routine" },
          { emoji: "📋", label: "Clear daily plan", sub: "Ticking goals every day" },
          { emoji: "💪", label: "30-day fitness", sub: "Challenge completed" },
          { emoji: "💰", label: "Budget on track", sub: "Saved $200 this month" },
          { emoji: "🏆", label: "Goals crushed", sub: "Best summer yet!" },
        ].map((item, i) => (
          <g key={i}>
            <rect x="302" y={150 + i * 60} width="186" height="48" rx="10" fill="white" fillOpacity="0.7" />
            <text x="328" y={174 + i * 60} fontSize="18" fontFamily="system-ui">{item.emoji}</text>
            <text x="350" y={169 + i * 60} fontSize="10.5" fontWeight="700" fill="#064e3b" fontFamily="system-ui">{item.label}</text>
            <text x="350" y={183 + i * 60} fontSize="9.5" fill="#6b7280" fontFamily="system-ui">{item.sub}</text>
            {/* Check mark */}
            <circle cx="464" cy={174 + i * 60} r="10" fill="#14b8a6" />
            <text x="464" y="178.5" dy={i * 60} textAnchor="middle" fontSize="10" fill="white" fontFamily="system-ui">✓</text>
          </g>
        ))}
      </g>

      {/* Bottom CTA */}
      <rect x="90" y="493" width="340" height="64" rx="16" fill="#0f2027" />
      <text x="260" y="516" textAnchor="middle" fontSize="11" fontWeight="700" fill="#FFB703" letterSpacing="1" fontFamily="system-ui">THIS COULD BE YOUR SUMMER</text>
      <text x="260" y="536" textAnchor="middle" fontSize="14" fontWeight="900" fill="white" fontFamily="system-ui">The planner makes the difference.</text>
      <text x="260" y="551" textAnchor="middle" fontSize="10.5" fill="rgba(255,255,255,0.6)" fontFamily="system-ui">$9.99 · instant download</text>
    </svg>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
   Mockup 3 — Content Spread: "48 Pages of Pure Action"
───────────────────────────────────────────────────────────────────────── */
export function DeskMockup({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 520 580" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        <linearGradient id="bg3" x1="0" y1="0" x2="0.5" y2="1">
          <stop offset="0%" stopColor="#fdf4ff" />
          <stop offset="100%" stopColor="#f5f0ff" />
        </linearGradient>
        <filter id="sh4">
          <feDropShadow dx="0" dy="4" stdDeviation="8" floodColor="#7c3aed" floodOpacity="0.1" />
        </filter>
        <linearGradient id="card1g" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#14b8a6" />
          <stop offset="100%" stopColor="#0d9488" />
        </linearGradient>
        <linearGradient id="card2g" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFB703" />
          <stop offset="100%" stopColor="#d97706" />
        </linearGradient>
        <linearGradient id="card3g" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#8b5cf6" />
          <stop offset="100%" stopColor="#7c3aed" />
        </linearGradient>
        <linearGradient id="card4g" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f97316" />
          <stop offset="100%" stopColor="#ea580c" />
        </linearGradient>
      </defs>

      <rect width="520" height="580" fill="url(#bg3)" />
      <circle cx="80" cy="80" r="80" fill="#8b5cf6" fillOpacity="0.06" />
      <circle cx="440" cy="500" r="100" fill="#FFB703" fillOpacity="0.06" />

      {/* Header */}
      <text x="260" y="44" textAnchor="middle" fontSize="11" fontWeight="700" fill="#8b5cf6" letterSpacing="3" fontFamily="system-ui">INSIDE THE PLANNER</text>
      <text x="260" y="72" textAnchor="middle" fontSize="21" fontWeight="900" fill="#0f2027" letterSpacing="-0.5" fontFamily="system-ui">48 pages of pure action</text>

      {/* ── Card 1: Habit Tracker ── */}
      <g filter="url(#sh4)">
        <rect x="20" y="95" width="228" height="196" rx="14" fill="white" />
        <rect x="20" y="95" width="228" height="44" rx="14" fill="url(#card1g)" />
        <rect x="20" y="119" width="228" height="20" fill="url(#card1g)" />
        <text x="52" y="113" fontSize="16" fontFamily="system-ui">✅</text>
        <text x="72" y="113" fontSize="10" fontWeight="800" fill="white" letterSpacing="1" fontFamily="system-ui">HABIT TRACKER</text>
        <text x="72" y="126" fontSize="8.5" fill="rgba(255,255,255,0.75)" fontFamily="system-ui">Build winning daily habits</text>

        {/* Habit grid */}
        {["Morning run", "Read 20 pages", "Gratitude", "Drink water", "No phone 1hr"].map((h, i) => {
          const filled = [7, 5, 7, 6, 4];
          return (
            <g key={i}>
              <text x="30" y={155 + i * 24} fontSize="8" fill="#475569" fontFamily="system-ui" fontWeight="500">{h}</text>
              {Array.from({ length: 7 }, (_, j) => (
                <rect key={j} x={118 + j * 17} y={142 + i * 24} width="13" height="13" rx="3"
                  fill={j < filled[i] ? "#14b8a6" : "#f1f5f9"}
                />
              ))}
            </g>
          );
        })}
        <text x="134" y="285" textAnchor="middle" fontSize="8" fill="#94a3b8" fontFamily="system-ui">Mon → Sun streak view</text>
      </g>

      {/* ── Card 2: Bucket List ── */}
      <g filter="url(#sh4)">
        <rect x="272" y="95" width="228" height="196" rx="14" fill="white" />
        <rect x="272" y="95" width="228" height="44" rx="14" fill="url(#card2g)" />
        <rect x="272" y="119" width="228" height="20" fill="url(#card2g)" />
        <text x="304" y="113" fontSize="16" fontFamily="system-ui">🪣</text>
        <text x="324" y="113" fontSize="10" fontWeight="800" fill="white" letterSpacing="1" fontFamily="system-ui">BUCKET LIST</text>
        <text x="324" y="126" fontSize="8.5" fill="rgba(255,255,255,0.75)" fontFamily="system-ui">50 ideas to live this summer</text>

        {[
          { t: "Watch a sunrise", done: true },
          { t: "Cook a new recipe", done: true },
          { t: "Go on a road trip", done: false },
          { t: "Read 3 books", done: true },
          { t: "Learn a new skill", done: false },
          { t: "Volunteer for a day", done: false },
          { t: "Try cold plunge", done: true },
        ].map((item, i) => (
          <g key={i}>
            {item.done
              ? <rect x="284" y={148 + i * 20} width="13" height="13" rx="3" fill="#FFB703" />
              : <rect x="284" y={148 + i * 20} width="13" height="13" rx="3" fill="none" stroke="#e2e8f0" strokeWidth="1.5" />
            }
            {item.done && <text x="284" y={158 + i * 20} fontSize="9" fill="white" fontFamily="system-ui" fontWeight="700" dx="1">✓</text>}
            <text x="302" y={159 + i * 20} fontSize="8.5" fill={item.done ? "#94a3b8" : "#334155"} fontFamily="system-ui"
              style={item.done ? { textDecoration: "line-through" } : {}}>{item.t}</text>
          </g>
        ))}
      </g>

      {/* ── Card 3: Challenges ── */}
      <g filter="url(#sh4)">
        <rect x="20" y="307" width="228" height="196" rx="14" fill="white" />
        <rect x="20" y="307" width="228" height="44" rx="14" fill="url(#card3g)" />
        <rect x="20" y="331" width="228" height="20" fill="url(#card3g)" />
        <text x="52" y="325" fontSize="16" fontFamily="system-ui">🏆</text>
        <text x="72" y="325" fontSize="10" fontWeight="800" fill="white" letterSpacing="1" fontFamily="system-ui">75 CHALLENGES</text>
        <text x="72" y="338" fontSize="8.5" fill="rgba(255,255,255,0.75)" fontFamily="system-ui">Level up through the summer</text>

        {/* Challenge level badges */}
        {[
          { label: "Level 1 · Starter", count: "25 challenges", color: "#bbf7d0", text: "#065f46" },
          { label: "Level 2 · Builder", count: "25 challenges", color: "#fef9c3", text: "#78350f" },
          { label: "Level 3 · Champion", count: "25 challenges", color: "#ede9fe", text: "#4c1d95" },
        ].map((l, i) => (
          <g key={i}>
            <rect x="30" y={360 + i * 45} width="200" height="35" rx="8" fill={l.color} />
            <text x="48" y={374 + i * 45} fontSize="10" fontWeight="700" fill={l.text} fontFamily="system-ui">{l.label}</text>
            <text x="48" y={388 + i * 45} fontSize="8.5" fill={l.text} fillOpacity="0.7" fontFamily="system-ui">{l.count}</text>
            <text x="208" y={380 + i * 45} textAnchor="middle" fontSize="14" fontFamily="system-ui">
              {i === 0 ? "⭐" : i === 1 ? "⭐⭐" : "⭐⭐⭐"}
            </text>
          </g>
        ))}

        <text x="134" y="497" textAnchor="middle" fontSize="8" fill="#94a3b8" fontFamily="system-ui">Complete all 75 to become a Summer Champion</text>
      </g>

      {/* ── Card 4: Weekly Planner ── */}
      <g filter="url(#sh4)">
        <rect x="272" y="307" width="228" height="196" rx="14" fill="white" />
        <rect x="272" y="307" width="228" height="44" rx="14" fill="url(#card4g)" />
        <rect x="272" y="331" width="228" height="20" fill="url(#card4g)" />
        <text x="304" y="325" fontSize="16" fontFamily="system-ui">📅</text>
        <text x="324" y="325" fontSize="10" fontWeight="800" fill="white" letterSpacing="1" fontFamily="system-ui">WEEKLY PLANNER</text>
        <text x="324" y="338" fontSize="8.5" fill="rgba(255,255,255,0.75)" fontFamily="system-ui">Plan every week intentionally</text>

        {/* Week grid */}
        {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
          <g key={i}>
            <rect x={284 + i * 30} y={358} width="24" height="24" rx="5"
              fill={i < 5 ? "#ffedd5" : "#fff7ed"} />
            <text x={296 + i * 30} y={374} textAnchor="middle" fontSize="9" fontWeight="700"
              fill={i < 5 ? "#ea580c" : "#fdba74"} fontFamily="system-ui">{d}</text>
          </g>
        ))}

        {/* Task rows */}
        {["Top priority", "Work block", "Self-care", "Evening plan"].map((t, i) => (
          <g key={i}>
            <rect x="284" y={390 + i * 22} width="6" height="14" rx="2"
              fill={["#f97316", "#FFB703", "#14b8a6", "#8b5cf6"][i]} />
            <rect x="296" y={392 + i * 22} width="140" height="10" rx="3" fill="#f8fafc" />
            <text x="300" y={401 + i * 22} fontSize="7.5" fill="#64748b" fontFamily="system-ui">{t}</text>
          </g>
        ))}

        {/* Mini finance bar */}
        <rect x="284" y="482" width="200" height="14" rx="4" fill="#fff7ed" />
        <rect x="284" y="482" width="136" height="14" rx="4" fill="#f97316" fillOpacity="0.6" />
        <text x="390" y="493" textAnchor="middle" fontSize="7" fill="#c2410c" fontFamily="system-ui" fontWeight="600">Budget: 68% used</text>
      </g>

      {/* Bottom bar */}
      <rect x="50" y="517" width="420" height="42" rx="21" fill="#0f2027" />
      <text x="260" y="533" textAnchor="middle" fontSize="9" fontWeight="700" fill="#8b5cf6" letterSpacing="1.5" fontFamily="system-ui">ALL THIS FOR $9.99</text>
      <text x="260" y="550" textAnchor="middle" fontSize="11.5" fontWeight="800" fill="white" fontFamily="system-ui">Download instantly · No subscription</text>
    </svg>
  );
}
