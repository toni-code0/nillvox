export default function PlannerCover({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 600 600"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="nillvox — Level Up Your Summer 2026 Planner Cover"
    >
      <defs>
        <radialGradient id="sunGlow" cx="15%" cy="12%" r="35%">
          <stop offset="0%" stopColor="#FFAB5E" stopOpacity="0.85" />
          <stop offset="50%" stopColor="#FFD49A" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#FFD49A" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="sunGlow2" cx="15%" cy="12%" r="18%">
          <stop offset="0%" stopColor="#FFAB5E" stopOpacity="1" />
          <stop offset="100%" stopColor="#FFAB5E" stopOpacity="0.5" />
        </radialGradient>
      </defs>

      {/* ── White background ── */}
      <rect width="600" height="600" fill="#FFFFFF" />

      {/* ── Peach blob — top right ── */}
      <path
        d="M600 0 Q560 0 530 30 Q490 70 520 110 Q545 140 590 120 Q620 105 610 60 Z"
        fill="#F5C9A4" fillOpacity="0.55"
      />
      <path
        d="M580 0 L600 0 L600 80 Q590 100 570 90 Q545 75 550 45 Q555 18 580 0 Z"
        fill="#F5C9A4" fillOpacity="0.35"
      />

      {/* ── Peach blob — bottom left ── */}
      <path
        d="M0 420 Q30 390 70 400 Q110 410 120 450 Q130 490 90 510 Q45 530 20 500 Q-10 465 0 420 Z"
        fill="#F5C9A4" fillOpacity="0.6"
      />
      <path
        d="M0 480 Q40 460 80 480 Q110 495 100 530 Q85 560 50 565 Q10 568 0 540 Z"
        fill="#F5C9A4" fillOpacity="0.45"
      />
      <path
        d="M0 540 Q30 525 60 540 Q80 552 75 575 Q65 595 30 598 Q5 600 0 585 Z"
        fill="#F5C9A4" fillOpacity="0.4"
      />

      {/* ── Peach blob — bottom right ── */}
      <path
        d="M600 430 Q570 415 545 435 Q510 460 520 500 Q530 535 565 545 Q595 552 608 520 Q618 488 600 430 Z"
        fill="#F5C9A4" fillOpacity="0.55"
      />
      <path
        d="M600 520 Q575 505 555 520 Q535 538 545 565 Q555 590 585 598 Q608 604 610 580 Q615 550 600 520 Z"
        fill="#F5C9A4" fillOpacity="0.4"
      />

      {/* ── Sun glow — top left ── */}
      <circle cx="90" cy="72" r="140" fill="url(#sunGlow)" />
      <circle cx="75" cy="60" r="62" fill="url(#sunGlow2)" />

      {/* ── Premium badge circle (white) ── */}
      <circle cx="82" cy="75" r="58" fill="#FFFFFF" />
      <circle cx="82" cy="75" r="58" fill="none" stroke="#e8d5c0" strokeWidth="1.2" />
      <text x="82" y="58" textAnchor="middle" fontSize="11" fontStyle="italic" fill="#333" fontFamily="Georgia, serif">premium</text>
      <text x="82" y="73" textAnchor="middle" fontSize="11.5" fontStyle="italic" fill="#333" fontFamily="Georgia, serif">best-seller</text>
      <text x="82" y="88" textAnchor="middle" fontSize="10" fontStyle="italic" fill="#888" fontFamily="Georgia, serif">digital pdf</text>
      {/* Small arrow into badge */}
      <path d="M106 38 Q115 28 122 36" fill="none" stroke="#555" strokeWidth="1.5" strokeLinecap="round" />
      <polygon points="122,36 116,40 120,33" fill="#555" />

      {/* ── Leaf icon — top right (sketch style) ── */}
      <g transform="translate(528, 22)" fill="none" stroke="#888" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 42 Q-2 28 4 8 Q18 0 34 14 Q44 24 30 42 Z" />
        <line x1="18" y1="42" x2="18" y2="10" />
        <line x1="10" y1="28" x2="18" y2="20" />
        <line x1="26" y1="22" x2="18" y2="14" />
      </g>

      {/* ── Small sun sketch + "Level Your" — top center ── */}
      {/* Sketch sun */}
      <g transform="translate(210, 42)" fill="none" stroke="#888" strokeWidth="1.3" strokeLinecap="round">
        <circle cx="20" cy="18" r="9" />
        {[0,45,90,135,180,225,270,315].map((a, i) => {
          const rad = a * Math.PI / 180;
          return <line key={i} x1={20 + Math.cos(rad)*13} y1={18 + Math.sin(rad)*13} x2={20 + Math.cos(rad)*18} y2={18 + Math.sin(rad)*18} />;
        })}
      </g>
      <text x="254" y="53" fontSize="12.5" fontStyle="italic" fill="#555" fontFamily="Georgia, serif">Level Your</text>
      <text x="248" y="68" fontSize="12" fontStyle="italic" fill="#777" fontFamily="Georgia, serif">Summer Planner</text>

      {/* ── MAIN TITLE — serif, large ── */}
      {/* "Level Up Your" */}
      <text
        x="300"
        y="192"
        textAnchor="middle"
        fontSize="68"
        fontWeight="700"
        fill="#1a1a1a"
        fontFamily="Georgia, 'Times New Roman', serif"
        letterSpacing="-1"
      >
        Level Up Your
      </text>
      {/* "Summer 2026" */}
      <text
        x="300"
        y="272"
        textAnchor="middle"
        fontSize="68"
        fontWeight="700"
        fill="#1a1a1a"
        fontFamily="Georgia, 'Times New Roman', serif"
        letterSpacing="-1"
      >
        Summer 2026
      </text>

      {/* Gold underline */}
      <rect x="218" y="285" width="164" height="3" rx="1.5" fill="#C9882A" />

      {/* ── Subtitle ── */}
      <text
        x="300"
        y="330"
        textAnchor="middle"
        fontSize="15.5"
        fontWeight="700"
        fill="#1a1a1a"
        fontFamily="system-ui, sans-serif"
        letterSpacing="0.3"
      >
        Your Complete Summer Reset Planner
      </text>

      {/* ── Description line ── */}
      <text x="300" y="358" textAnchor="middle" fontSize="11.5" fill="#888" fontFamily="system-ui, sans-serif">
        The planner that combines your best summer goals,
      </text>
      <text x="300" y="373" textAnchor="middle" fontSize="11.5" fill="#888" fontFamily="system-ui, sans-serif">
        habits, challenges &amp; reflection — all in one.
      </text>

      {/* ── Stats row ── */}
      <text x="165" y="428" textAnchor="middle" fontSize="38" fontWeight="300" fill="#1a1a1a" fontFamily="Georgia, serif">75</text>
      <text x="165" y="450" textAnchor="middle" fontSize="10.5" fontWeight="600" fill="#888" letterSpacing="0.5" fontFamily="system-ui">Challenges Included</text>

      {/* Divider dots */}
      <circle cx="258" cy="435" r="3" fill="#e0c9b0" />

      <text x="300" y="428" textAnchor="middle" fontSize="38" fontWeight="300" fill="#1a1a1a" fontFamily="Georgia, serif">50</text>
      <text x="300" y="450" textAnchor="middle" fontSize="10.5" fontWeight="600" fill="#888" letterSpacing="0.5" fontFamily="system-ui">Bucket List Ideas</text>

      <circle cx="342" cy="435" r="3" fill="#e0c9b0" />

      <text x="435" y="428" textAnchor="middle" fontSize="38" fontWeight="300" fill="#1a1a1a" fontFamily="Georgia, serif">30</text>
      <text x="435" y="450" textAnchor="middle" fontSize="10.5" fontWeight="600" fill="#888" letterSpacing="0.5" fontFamily="system-ui">Motivational Quotes</text>

      {/* ── Hand-drawn wavy lines (bottom) ── */}
      {/* Left squiggles */}
      <g fill="none" stroke="#aaa" strokeWidth="1.2" strokeLinecap="round">
        <path d="M28 490 Q38 483 48 490 Q58 497 68 490" />
        <path d="M20 506 Q32 498 44 506 Q56 514 68 506 Q80 498 92 506" />
        <path d="M30 522 Q44 513 58 522 Q72 531 86 522 Q100 513 114 522" />
        <path d="M15 538 Q32 528 49 538 Q66 548 83 538 Q100 528 117 538" />
        <path d="M22 554 Q40 543 58 554 Q76 565 94 554 Q112 543 130 554" />
        <path d="M10 570 Q30 558 50 570 Q70 582 90 570 Q110 558 130 570 Q150 582 170 570" />
      </g>

      {/* Right squiggles */}
      <g fill="none" stroke="#aaa" strokeWidth="1.2" strokeLinecap="round">
        <path d="M510 486 Q522 478 534 486 Q546 494 558 486" />
        <path d="M496 502 Q510 493 524 502 Q538 511 552 502 Q566 493 580 502" />
        <path d="M482 518 Q498 508 514 518 Q530 528 546 518 Q562 508 578 518 Q594 528 610 518" />
        <path d="M468 534 Q486 523 504 534 Q522 545 540 534 Q558 523 576 534" />
        <path d="M474 550 Q494 538 514 550 Q534 562 554 550 Q574 538 594 550" />
        <path d="M460 566 Q482 553 504 566 Q526 579 548 566 Q570 553 592 566" />
      </g>

      {/* ── Crescent moon — bottom right ── */}
      <g transform="translate(538, 510)" fill="none" stroke="#888" strokeWidth="1.5" strokeLinecap="round">
        <path d="M16 4 Q6 12 6 22 Q6 34 16 40 Q4 36 0 24 Q-2 10 16 4 Z" />
      </g>

      {/* ── Small decorative wave marks — scattered ── */}
      {/* Left side middle */}
      <path d="M22 370 Q30 364 38 370" fill="none" stroke="#ccc" strokeWidth="1.3" strokeLinecap="round" />
      <path d="M18 382 Q28 375 38 382" fill="none" stroke="#ccc" strokeWidth="1.3" strokeLinecap="round" />

      {/* Right side middle */}
      <path d="M558 355 Q568 348 578 355" fill="none" stroke="#ccc" strokeWidth="1.3" strokeLinecap="round" />
      <path d="M554 368 Q566 361 578 368" fill="none" stroke="#ccc" strokeWidth="1.3" strokeLinecap="round" />

      {/* ── Pizza/triangle sketch — right side (matching reference) ── */}
      <g transform="translate(548, 148)" fill="none" stroke="#888" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 0 Q32 2 38 16 Q28 28 8 28 Q0 14 18 0 Z" />
        <path d="M18 0 Q22 14 8 28" />
        <circle cx="24" cy="12" r="2.5" />
        <circle cx="16" cy="20" r="2" />
      </g>

      {/* ── Bottom gold accent bar ── */}
      <rect x="0" y="596" width="600" height="4" fill="#C9882A" fillOpacity="0.7" />
    </svg>
  );
}
