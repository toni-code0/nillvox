export function HabitTrackerMockup({ className = "" }: { className?: string }) {
  const habits = ["Morning routine", "Exercise 30 min", "Read 20 pages", "Gratitude journal", "Drink 2L water", "No screens 1hr"];
  const days = ["M", "T", "W", "T", "F", "S", "S"];
  return (
    <svg viewBox="0 0 480 560" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        <linearGradient id="hbg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f0fdf4" />
          <stop offset="100%" stopColor="#f8fafc" />
        </linearGradient>
      </defs>
      <rect width="480" height="560" fill="url(#hbg)" />
      <rect x="0" y="0" width="480" height="4" fill="#14b8a6" />

      {/* Header band */}
      <rect x="0" y="4" width="480" height="72" fill="#0d1f3c" />
      <text x="30" y="32" fontSize="9" fontWeight="700" fill="#14b8a6" letterSpacing="3" fontFamily="system-ui">HABIT TRACKER</text>
      <text x="30" y="56" fontSize="20" fontWeight="900" fill="#ffffff" letterSpacing="-0.5" fontFamily="system-ui">June 2026</text>
      <text x="420" y="46" fontSize="11" fill="#14b8a6" fontFamily="system-ui" fontWeight="700">WEEK 1</text>

      {/* Day headers */}
      {days.map((d, i) => (
        <g key={i}>
          <rect x={230 + i * 34} y="90" width="28" height="28" rx="6" fill={i < 5 ? "#e0f2fe" : "#fef3c7"} />
          <text x={244 + i * 34} y="109" textAnchor="middle" fontSize="11" fontWeight="800" fill={i < 5 ? "#0ea5e9" : "#f59e0b"} fontFamily="system-ui">{d}</text>
        </g>
      ))}

      {/* Habit rows */}
      {habits.map((habit, row) => {
        const checked = [
          [1, 1, 1, 0, 1, 1, 0],
          [1, 1, 0, 1, 1, 0, 1],
          [0, 1, 1, 1, 0, 1, 1],
          [1, 0, 1, 1, 1, 1, 0],
          [1, 1, 1, 0, 0, 1, 1],
          [0, 1, 0, 1, 1, 0, 1],
        ][row];
        const y = 142 + row * 56;
        return (
          <g key={row}>
            <rect x="20" y={y - 18} width="480" height="52" fill={row % 2 === 0 ? "#ffffff" : "#f8fafc"} rx="8" />
            <rect x="20" y={y - 18} width="3" height="52" fill="#14b8a6" fillOpacity="0.4" rx="2" />
            <text x="36" y={y + 8} fontSize="12" fontWeight="600" fill="#1e293b" fontFamily="system-ui">{habit}</text>
            {days.map((_, i) => (
              <g key={i}>
                {checked[i] ? (
                  <g>
                    <rect x={233 + i * 34} y={y - 12} width="22" height="22" rx="6" fill="#14b8a6" />
                    <text x={244 + i * 34} y={y + 5} textAnchor="middle" fontSize="12" fill="white" fontFamily="system-ui">✓</text>
                  </g>
                ) : (
                  <rect x={233 + i * 34} y={y - 12} width="22" height="22" rx="6" fill="none" stroke="#cbd5e1" strokeWidth="1.5" />
                )}
              </g>
            ))}
          </g>
        );
      })}

      {/* Footer */}
      <rect x="20" y="496" width="440" height="44" rx="10" fill="#0d1f3c" fillOpacity="0.05" />
      <text x="240" y="515" textAnchor="middle" fontSize="10" fill="#64748b" fontFamily="system-ui" fontWeight="600">WEEKLY STREAK</text>
      {[0,1,2,3,4,5,6].map(i => (
        <rect key={i} x={100 + i * 46} y="524" width="32" height="8" rx="4" fill={i < 5 ? "#14b8a6" : "#e2e8f0"} />
      ))}
      <rect x="0" y="556" width="480" height="4" fill="#14b8a6" />
    </svg>
  );
}

export function BucketListMockup({ className = "" }: { className?: string }) {
  const items = [
    { text: "Watch the sunrise from a hilltop", done: true },
    { text: "Read 10 books before summer ends", done: true },
    { text: "Complete a 30-day fitness challenge", done: false },
    { text: "Take a spontaneous day trip", done: true },
    { text: "Start journaling every single day", done: false },
    { text: "Learn a new language (20 min daily)", done: true },
    { text: "Attend a live concert or festival", done: false },
    { text: "Try a new water sport", done: false },
    { text: "Write and finish a short story", done: true },
    { text: "Complete an online certification", done: false },
  ];
  return (
    <svg viewBox="0 0 480 560" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        <linearGradient id="bbg" x1="0" y1="0" x2="0.5" y2="1">
          <stop offset="0%" stopColor="#fff7ed" />
          <stop offset="100%" stopColor="#fafaf9" />
        </linearGradient>
      </defs>
      <rect width="480" height="560" fill="url(#bbg)" />
      <rect x="0" y="0" width="480" height="4" fill="#f59e0b" />

      {/* Header */}
      <rect x="0" y="4" width="480" height="80" fill="#0d1f3c" />
      <text x="30" y="32" fontSize="9" fontWeight="700" fill="#f59e0b" letterSpacing="3" fontFamily="system-ui">BUCKET LIST</text>
      <text x="30" y="62" fontSize="20" fontWeight="900" fill="#ffffff" letterSpacing="-0.5" fontFamily="system-ui">50 Summer Experiences</text>

      {/* Progress */}
      <rect x="320" y="36" width="130" height="34" rx="8" fill="#ffffff" fillOpacity="0.08" />
      <text x="385" y="50" textAnchor="middle" fontSize="9" fill="#f59e0b" fontFamily="system-ui" fontWeight="700">COMPLETED</text>
      <text x="385" y="66" textAnchor="middle" fontSize="14" fontWeight="900" fill="#ffffff" fontFamily="system-ui">4 / 50</text>

      {/* Items */}
      {items.map((item, i) => {
        const y = 110 + i * 42;
        return (
          <g key={i}>
            <rect x="20" y={y} width="440" height="36" rx="8" fill={item.done ? "#fef3c7" : "#ffffff"} stroke={item.done ? "#f59e0b" : "#e2e8f0"} strokeWidth="1" />
            {item.done ? (
              <g>
                <rect x="32" y={y + 8} width="20" height="20" rx="6" fill="#f59e0b" />
                <text x="42" y={y + 22} textAnchor="middle" fontSize="12" fill="white" fontFamily="system-ui">✓</text>
              </g>
            ) : (
              <rect x="32" y={y + 8} width="20" height="20" rx="6" fill="none" stroke="#d1d5db" strokeWidth="1.5" />
            )}
            <text x="62" y={y + 21} fontSize="11.5" fontWeight={item.done ? "700" : "500"} fill={item.done ? "#92400e" : "#374151"} fontFamily="system-ui"
              textDecoration={item.done ? "line-through" : "none"}
            >{i + 1}. {item.text}</text>
          </g>
        );
      })}

      <rect x="0" y="556" width="480" height="4" fill="#f59e0b" />
    </svg>
  );
}

export function WeeklyPlannerMockup({ className = "" }: { className?: string }) {
  const days2 = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
  const dates = ["2", "3", "4", "5", "6", "7", "8"];
  const tasks = [
    ["Morning run", "Read ch. 3", "Plan week"],
    ["Gym 6am", "Online course"],
    ["Study session", "Cook new recipe", "Journaling"],
    ["Rest day", "Savings review"],
    ["Yoga class", "Read 20 pages"],
    ["Bucket list item!", "Movie night"],
    ["Weekly review", "Set goals"],
  ];
  return (
    <svg viewBox="0 0 480 560" xmlns="http://www.w3.org/2000/svg" className={className}>
      <rect width="480" height="560" fill="#f8fafc" />
      <rect x="0" y="0" width="480" height="4" fill="#0ea5e9" />

      {/* Header */}
      <rect x="0" y="4" width="480" height="70" fill="#0d1f3c" />
      <text x="30" y="30" fontSize="9" fontWeight="700" fill="#0ea5e9" letterSpacing="3" fontFamily="system-ui">WEEKLY PLANNER</text>
      <text x="30" y="56" fontSize="20" fontWeight="900" fill="#ffffff" fontFamily="system-ui">Week 1 · June 2026</text>
      <text x="420" y="46" fontSize="10" fill="#0ea5e9" fontFamily="system-ui" fontWeight="700">STREAK: 5🔥</text>

      {/* Day columns */}
      {days2.map((day, i) => {
        const col = i < 4 ? i : i - 4;
        const row = i < 4 ? 0 : 1;
        const x = 14 + col * 115;
        const y = 88 + row * 218;
        const isWeekend = i >= 5;
        return (
          <g key={i}>
            <rect x={x} y={y} width="108" height="200" rx="10" fill={isWeekend ? "#f0f9ff" : "#ffffff"} stroke={isWeekend ? "#bae6fd" : "#e2e8f0"} strokeWidth="1" />
            <rect x={x} y={y} width="108" height="36" rx="10" fill={isWeekend ? "#0ea5e9" : "#1e293b"} />
            <rect x={x} y={y + 18} width="108" height="18" fill={isWeekend ? "#0ea5e9" : "#1e293b"} />
            <text x={x + 54} y={y + 15} textAnchor="middle" fontSize="9.5" fontWeight="800" fill="#ffffff" letterSpacing="2" fontFamily="system-ui">{day}</text>
            <text x={x + 54} y={y + 30} textAnchor="middle" fontSize="15" fontWeight="900" fill={isWeekend ? "#e0f2fe" : "#94a3b8"} fontFamily="system-ui">{dates[i]}</text>

            {tasks[i].map((task, j) => (
              <g key={j}>
                <rect x={x + 8} y={y + 46 + j * 44} width="92" height="38" rx="6" fill={isWeekend ? "#e0f2fe" : "#f8fafc"} />
                <rect x={x + 8} y={y + 46 + j * 44} width="3" height="38" rx="2" fill={isWeekend ? "#0ea5e9" : "#14b8a6"} />
                <text x={x + 16} y={y + 60 + j * 44} fontSize="9.5" fontWeight="600" fill="#334155" fontFamily="system-ui">{task}</text>
              </g>
            ))}
          </g>
        );
      })}

      {/* Bottom note */}
      <rect x="14" y="526" width="452" height="26" rx="8" fill="#0d1f3c" fillOpacity="0.06" />
      <text x="240" y="544" textAnchor="middle" fontSize="10" fill="#64748b" fontFamily="system-ui" fontWeight="600">"Small daily improvements lead to stunning results." — Level Up 2026</text>
      <rect x="0" y="556" width="480" height="4" fill="#0ea5e9" />
    </svg>
  );
}
