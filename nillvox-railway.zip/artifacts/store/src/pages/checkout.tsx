import { useState, useEffect, useRef } from "react";
import { useLocation, Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Lock, CreditCard, CheckCircle2, ArrowLeft, Shield, ChevronDown } from "lucide-react";

import { useCreateOrder, useConfirmOrder } from "@workspace/api-client-react";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

const cardSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email" }),
  name: z.string().min(2, { message: "Please enter your full name" }),
  cardNumber: z.string().min(16, "Invalid card number"),
  expiry: z.string().regex(/^(0[1-9]|1[0-2])\/\d{2}$/, "MM/YY required"),
  cvv: z.string().min(3).max(4, "Invalid CVV"),
});

type CardValues = z.infer<typeof cardSchema>;

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const initialTab = new URLSearchParams(window.location.search).get("tab") === "paypal" ? "paypal" : "card";
  const [payMethod, setPayMethod] = useState<"card" | "paypal">(initialTab as "card" | "paypal");
  const [cardExpanded, setCardExpanded] = useState(false);

  const createOrder = useCreateOrder();
  const confirmOrder = useConfirmOrder();
  const paypalRendered = useRef(false);
  const isProcessing = createOrder.isPending || confirmOrder.isPending;

  const form = useForm<CardValues>({
    resolver: zodResolver(cardSchema),
    defaultValues: { email: "", name: "", cardNumber: "", expiry: "", cvv: "" },
  });

  const processPayment = async (email: string, name: string, paypalOrderId: string, method: "card" | "paypal") => {
    const order = await createOrder.mutateAsync({ data: { email, name, paymentMethod: method } });
    const tokenData = await confirmOrder.mutateAsync({ id: order.id, data: { paypalOrderId } });
    setLocation(`/success?token=${tokenData.token}`);
  };

  const onSubmitCard = async (values: CardValues) => {
    try {
      await processPayment(values.email, values.name, "CARD_PAYMENT_DEMO", "card");
    } catch {
      toast({ title: "Payment failed", description: "Please check your card details and try again.", variant: "destructive" });
    }
  };

  useEffect(() => {
    if (payMethod !== "paypal" || paypalRendered.current) return;
    const timer = setTimeout(() => {
      const container = document.getElementById("paypal-btn-container");
      if (!container) return;
      container.innerHTML = "";
      const sdk = (window as any).paypal;
      if (!sdk) return;
      paypalRendered.current = true;
      sdk.Buttons({
        fundingSource: sdk.FUNDING.PAYPAL,
        style: { layout: "vertical", color: "blue", shape: "rect", label: "paypal", height: 50 },
        createOrder: (_: unknown, actions: any) =>
          actions.order.create({
            purchase_units: [{ amount: { value: "9.99", currency_code: "USD" }, description: "Level Up Summer 2026 Planner Bundle" }],
          }),
        onApprove: async (data: any) => {
          try {
            const email = form.getValues("email") || "paypal@example.com";
            const name = form.getValues("name") || "";
            await processPayment(email, name, data.orderID, "paypal");
          } catch {
            toast({ title: "Payment failed", description: "Please try again.", variant: "destructive" });
          }
        },
        onError: () => { paypalRendered.current = false; },
      }).render("#paypal-btn-container").catch(() => { paypalRendered.current = false; });
    }, 50);
    return () => clearTimeout(timer);
  }, [payMethod]);

  return (
    <div className="min-h-screen bg-[#f5f6f8] font-sans pb-16">
      {/* Top bar */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-slate-400 hover:text-slate-700 text-sm transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span className="font-medium">Back</span>
          </Link>
          <div className="absolute left-1/2 -translate-x-1/2 font-black text-slate-900 text-lg tracking-tight">nillvox</div>
          <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-semibold">
            <Shield className="w-3.5 h-3.5" />
            256-bit SSL
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 pt-8">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmitCard)}>
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 items-start">

              {/* ── Left column ── */}
              <div className="lg:col-span-3 space-y-4">

                {/* Customer information */}
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                  <div className="px-6 pt-5 pb-2">
                    <h2 className="text-base font-bold text-slate-900">Customer information</h2>
                    <p className="text-xs text-slate-400 mt-0.5">We use this for billing and your receipt.</p>
                  </div>
                  <div className="px-6 pb-6 space-y-3 mt-2">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Email</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="you@example.com"
                              type="email"
                              autoComplete="email"
                              className="h-11 rounded-xl border-slate-200 bg-slate-50 focus:bg-white focus:border-slate-400 transition-all text-sm"
                              {...field}
                              data-testid="input-email"
                            />
                          </FormControl>
                          <FormMessage className="text-xs" />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Full name</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Jane Doe"
                              autoComplete="name"
                              className="h-11 rounded-xl border-slate-200 bg-slate-50 focus:bg-white focus:border-slate-400 transition-all text-sm"
                              {...field}
                              data-testid="input-name"
                            />
                          </FormControl>
                          <FormMessage className="text-xs" />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Payment method */}
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                  <div className="px-6 pt-5 pb-2 flex items-center justify-between">
                    <div>
                      <h2 className="text-base font-bold text-slate-900">Payment method</h2>
                      <p className="text-xs text-slate-400 mt-0.5">Choose how you want to pay. All transactions are encrypted.</p>
                    </div>
                    <div className="flex items-center gap-1 text-emerald-600 text-xs font-semibold bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-100 shrink-0">
                      <Lock className="w-3 h-3" />
                      256-bit SSL
                    </div>
                  </div>

                  <div className="px-6 pb-6 space-y-3 mt-2">
                    {/* ── Card option ── */}
                    <div
                      className={`rounded-xl border transition-all ${payMethod === "card" ? "border-slate-300" : "border-slate-200"}`}
                    >
                      {/* Card header row */}
                      <button
                        type="button"
                        onClick={() => { setPayMethod("card"); setCardExpanded(v => payMethod !== "card" ? true : !v); }}
                        className="w-full flex items-center justify-between px-4 py-3 cursor-pointer"
                        data-testid="tab-card"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 ${payMethod === "card" ? "border-slate-800" : "border-slate-300"}`}>
                            {payMethod === "card" && <div className="w-2 h-2 bg-slate-800 rounded-full" />}
                          </div>
                          <CreditCard className="w-4 h-4 text-slate-500 shrink-0" />
                          <div className="text-left">
                            <span className="text-sm font-semibold text-slate-900">Credit or debit card</span>
                            <div className="text-xs text-slate-400">Visa, Mastercard, Amex, Discover</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="hidden sm:flex gap-1">
                            <span className="bg-[#1A1F71] text-white text-[9px] font-bold px-1.5 py-0.5 rounded">VISA</span>
                            <span className="bg-[#EB001B] text-white text-[9px] font-bold px-1.5 py-0.5 rounded">MC</span>
                            <span className="bg-[#007BC1] text-white text-[9px] font-bold px-1.5 py-0.5 rounded">AMEX</span>
                          </div>
                          {payMethod === "card" && (
                            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${cardExpanded ? "rotate-180" : ""}`} />
                          )}
                        </div>
                      </button>

                      {/* Dark "Pay by Card" collapsed button */}
                      {payMethod === "card" && !cardExpanded && (
                        <div className="px-4 pb-4">
                          <button
                            type="button"
                            onClick={() => setCardExpanded(true)}
                            className="w-full h-12 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm flex items-center justify-center gap-2.5 transition-all shadow-sm"
                          >
                            <CreditCard className="w-4 h-4" />
                            Pay by card
                          </button>
                        </div>
                      )}

                      {/* Expanded card form */}
                      {payMethod === "card" && cardExpanded && (
                        <div className="px-4 pb-4 space-y-3" onClick={(e) => e.stopPropagation()}>
                          <div className="rounded-xl border border-slate-200 overflow-hidden bg-white">
                            <FormField
                              control={form.control}
                              name="cardNumber"
                              render={({ field }) => (
                                <FormItem className="space-y-0 border-b border-slate-100">
                                  <FormControl>
                                    <div className="relative">
                                      <CreditCard className="absolute left-3.5 top-3.5 h-4 w-4 text-slate-400" />
                                      <Input placeholder="Card number" maxLength={19} className="h-11 pl-10 border-0 focus-visible:ring-0 rounded-none bg-transparent text-sm" {...field} data-testid="input-cardnumber" />
                                    </div>
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <div className="flex border-t border-slate-100">
                              <FormField
                                control={form.control}
                                name="expiry"
                                render={({ field }) => (
                                  <FormItem className="space-y-0 flex-1 border-r border-slate-100">
                                    <FormControl>
                                      <Input placeholder="MM / YY" maxLength={5} className="h-11 border-0 focus-visible:ring-0 rounded-none bg-transparent text-sm" {...field} data-testid="input-expiry" />
                                    </FormControl>
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={form.control}
                                name="cvv"
                                render={({ field }) => (
                                  <FormItem className="space-y-0 flex-1">
                                    <FormControl>
                                      <Input placeholder="CVC" type="password" maxLength={4} className="h-11 border-0 focus-visible:ring-0 rounded-none bg-transparent text-sm" {...field} data-testid="input-cvv" />
                                    </FormControl>
                                  </FormItem>
                                )}
                              />
                            </div>
                          </div>

                          {(form.formState.errors.cardNumber || form.formState.errors.expiry || form.formState.errors.cvv) && (
                            <p className="text-xs text-red-500 font-medium">Please check your card details.</p>
                          )}

                          <button
                            type="submit"
                            disabled={isProcessing}
                            className="w-full h-12 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-60 text-white font-bold text-sm flex items-center justify-center gap-2.5 transition-all shadow-sm"
                            data-testid="button-pay-card"
                          >
                            {isProcessing ? (
                              <>
                                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                Processing…
                              </>
                            ) : (
                              <>
                                <Lock className="w-4 h-4" />
                                Pay $9.99 securely
                              </>
                            )}
                          </button>
                          <p className="text-center text-xs text-slate-400 flex items-center justify-center gap-1">
                            <Lock className="w-3 h-3" /> No card details stored · 256-bit encryption
                          </p>
                        </div>
                      )}
                    </div>

                    {/* OR divider */}
                    <div className="flex items-center gap-3">
                      <div className="h-px bg-slate-200 flex-1" />
                      <span className="text-xs font-semibold text-slate-400 uppercase">OR</span>
                      <div className="h-px bg-slate-200 flex-1" />
                    </div>

                    {/* ── PayPal option ── */}
                    <div className={`rounded-xl border transition-all ${payMethod === "paypal" ? "border-slate-300" : "border-slate-200"}`}>
                      <button
                        type="button"
                        onClick={() => setPayMethod("paypal")}
                        className="w-full flex items-center gap-3 px-4 py-3 cursor-pointer"
                        data-testid="tab-paypal"
                      >
                        <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 ${payMethod === "paypal" ? "border-slate-800" : "border-slate-300"}`}>
                          {payMethod === "paypal" && <div className="w-2 h-2 bg-slate-800 rounded-full" />}
                        </div>
                        <div className="flex items-center justify-center bg-[#003087]/8 px-2 py-1 rounded shrink-0">
                          <svg viewBox="0 0 24 24" className="w-4 h-4" fill="#003087">
                            <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106z" />
                          </svg>
                        </div>
                        <div className="text-left">
                          <span className="text-sm font-semibold text-slate-900">PayPal</span>
                          <div className="text-xs text-slate-400">Pay with your PayPal balance or linked bank</div>
                        </div>
                      </button>

                      {payMethod === "paypal" && (
                        <div className="px-4 pb-4" onClick={(e) => e.stopPropagation()}>
                          <div id="paypal-btn-container" data-testid="container-paypal" className="w-full min-h-[52px]" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* ── Right column: Order summary ── */}
              <div className="lg:col-span-2">
                <div className="bg-white rounded-2xl border border-slate-200 sticky top-6 overflow-hidden">
                  <div className="px-5 py-4 border-b border-slate-100">
                    <h2 className="text-base font-bold text-slate-900">Order summary</h2>
                    <p className="text-xs text-slate-400 mt-0.5">For creators and digital learners</p>
                  </div>

                  {/* Product block */}
                  <div className="px-5 py-4 border-b border-slate-100">
                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
                      <div className="text-[10px] font-bold tracking-widest text-teal-500 uppercase mb-1">nillvox</div>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="font-bold text-slate-900 text-sm leading-snug">Summer 2026 Planner Bundle</div>
                          <div className="text-xs text-slate-400 mt-0.5">Standard + Premium edition</div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="text-xs text-slate-400 line-through">$19.99</div>
                          <div className="font-black text-slate-900 text-base">$9.99</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="px-5 py-4 space-y-2 border-b border-slate-100">
                    {[
                      "48-page premium printable PDF",
                      "50-page interactive premium edition",
                      "75 summer challenges + level system",
                      "Habit, fitness & finance tracker",
                      "50 bucket list + 30 quotes",
                      "Instant digital download",
                    ].map((f, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-600">
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal-500 shrink-0 mt-0.5" />
                        <span>{f}</span>
                      </div>
                    ))}
                  </div>

                  {/* Price breakdown */}
                  <div className="px-5 py-4 space-y-2 border-b border-slate-100">
                    <div className="flex justify-between text-xs text-slate-500">
                      <span>Subtotal</span><span>$9.99</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-500">
                      <span>Taxes</span><span>$0.00</span>
                    </div>
                    <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                      <span className="text-sm font-bold text-slate-900">Total due today</span>
                      <span className="text-lg font-black text-slate-900">$9.99</span>
                    </div>
                  </div>

                  {/* Trust note */}
                  <div className="px-5 py-3 flex items-center gap-2 text-xs text-slate-500">
                    <CheckCircle2 className="w-3.5 h-3.5 text-teal-500 shrink-0" />
                    <span>Instant download after payment</span>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
