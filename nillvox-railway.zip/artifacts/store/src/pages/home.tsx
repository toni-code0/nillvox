import { Link } from "wouter";
import { motion, type Variants } from "framer-motion";
import { Check, Star, Shield, Lock, Zap, BookOpen, Activity, Dumbbell, DollarSign, Brain, Trophy, MapPin, Heart, ChevronDown, ChevronUp, Download } from "lucide-react";
import PlannerCover from "@/components/PlannerCover";
import { PhoneMockup, NotebookMockup, DeskMockup } from "@/components/LifestyleMockups";
import { useState } from "react";

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
  }),
};

function Stars({ n = 5 }: { n?: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: n }).map((_, i) => (
        <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
      ))}
    </div>
  );
}

const testimonials = [
  {
    name: "Sarah M.",
    handle: "@sarahdoesthings",
    avatar: "SM",
    text: "Honestly one of the best $9.99 I've ever spent. The habit tracker alone changed my entire summer routine. Downloaded it to GoodNotes and I'm obsessed.",
    stars: 5,
  },
  {
    name: "Jordan K.",
    handle: "@jkplans",
    avatar: "JK",
    text: "I've tried so many planners and this one actually sticks. The 75 challenges section pushed me to do things I kept putting off for years.",
    stars: 5,
  },
  {
    name: "Priya R.",
    handle: "@priyaresets",
    avatar: "PR",
    text: "The premium edition is gorgeous. I printed it out and it feels like a real journal. Highly recommend to anyone who wants structure this summer.",
    stars: 5,
  },
];

const faqs = [
  {
    q: "What do I receive after purchase?",
    a: "You'll instantly receive two PDF files — a Standard Edition (48 pages) and a Premium Interactive Edition — via a secure download page. No waiting, no shipping.",
  },
  {
    q: "What apps can I use this with?",
    a: "It works great in GoodNotes, Notability, Adobe Acrobat, or any PDF reader. You can also print it out on standard A4 or US Letter paper.",
  },
  {
    q: "Is this a one-time payment?",
    a: "Yes — $9.99 once. No subscriptions, no hidden fees. You own it forever once you download it.",
  },
  {
    q: "What if I lose my download link?",
    a: "Your download link is valid for 24 hours after purchase. Download both PDFs to your device right away and you'll have them forever.",
  },
];

function FAQ() {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <div className="divide-y divide-gray-100">
      {faqs.map((faq, i) => (
        <div key={i} className="py-5">
          <button
            className="w-full flex items-center justify-between gap-4 text-left group"
            onClick={() => setOpen(open === i ? null : i)}
          >
            <span className="font-semibold text-gray-900 text-base group-hover:text-[#0D1B3E] transition-colors">{faq.q}</span>
            {open === i
              ? <ChevronUp className="w-5 h-5 text-gray-400 flex-shrink-0" />
              : <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />}
          </button>
          {open === i && (
            <p className="mt-3 text-gray-500 text-sm leading-relaxed pr-8">{faq.a}</p>
          )}
        </div>
      ))}
    </div>
  );
}

export default function Home() {
  const features = [
    { title: "Planner Layouts", desc: "Daily, weekly, and monthly spreads designed for summer", icon: BookOpen },
    { title: "Habit Tracker", desc: "Build momentum and stay consistent all season", icon: Activity },
    { title: "Fitness Goals", desc: "Log workouts and stay active every week", icon: Dumbbell },
    { title: "Finance Reset", desc: "Track expenses and budget wisely this summer", icon: DollarSign },
    { title: "Learning Log", desc: "Books, skills, and courses — all in one place", icon: Brain },
    { title: "75 Challenges", desc: "Push your limits with daily challenge prompts", icon: Trophy },
    { title: "Bucket List", desc: "50 curated ideas to make summer unforgettable", icon: MapPin },
    { title: "Reflection Journal", desc: "Guided prompts to stay grounded and grow", icon: Heart },
  ];

  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans antialiased selection:bg-amber-100">

      {/* ── NAV ────────────────────────────────────────────────── */}
      <nav className="sticky top-0 z-50 bg-[#0D1B3E]/95 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
          <div className="font-display font-bold text-xl text-white tracking-tight">nillvox</div>
          <div className="flex items-center gap-3">
            <span className="hidden sm:block text-white/50 text-sm">$9.99 one-time</span>
            <Link
              href="/checkout"
              className="bg-amber-400 hover:bg-amber-300 text-[#0D1B3E] text-sm font-bold px-5 py-2 rounded-full transition-all hover:shadow-lg hover:shadow-amber-400/30"
              data-testid="link-nav-checkout"
            >
              Get Instant Access →
            </Link>
          </div>
        </div>
      </nav>

      {/* ── HERO ───────────────────────────────────────────────── */}
      <section className="relative overflow-hidden bg-[#0D1B3E] pt-20 pb-28 px-5 sm:px-8">
        {/* background decoration */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-amber-400/5 rounded-full blur-[120px]" />
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-blue-600/10 rounded-full blur-[100px]" />
          <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.03) 1px, transparent 0)", backgroundSize: "40px 40px" }} />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-16">
          {/* Left */}
          <motion.div
            variants={fadeUp} initial="hidden" animate="visible"
            className="flex-1 space-y-7 text-center lg:text-left"
          >
            <div className="inline-flex items-center gap-2 bg-amber-400/10 border border-amber-400/20 rounded-full px-4 py-1.5">
              <span className="w-2 h-2 bg-amber-400 rounded-full animate-pulse" />
              <span className="text-amber-400 text-xs font-bold tracking-widest uppercase">Summer 2026 Edition</span>
            </div>

            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-[1.08] tracking-tight">
              Your Best Summer<br />
              <span className="text-amber-400 italic">Starts Here</span>
            </h1>

            <p className="text-white/60 text-lg font-normal max-w-lg mx-auto lg:mx-0 leading-relaxed">
              The complete digital planner bundle that turns your summer 2026 into a season you'll actually remember. Habits, goals, fitness, finance — all in one PDF.
            </p>

            <ul className="space-y-3 text-left max-w-md mx-auto lg:mx-0">
              {[
                "2 editions: Standard + Premium Interactive PDF",
                "48+ pages · 75 challenges · 50 bucket list ideas",
                "Instant download — works in GoodNotes & Notability",
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-white/80 text-sm font-medium">
                  <div className="w-5 h-5 rounded-full bg-amber-400/20 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3 text-amber-400" />
                  </div>
                  {item}
                </li>
              ))}
            </ul>

            {/* Social proof mini */}
            <div className="flex items-center gap-3 justify-center lg:justify-start">
              <div className="flex -space-x-2">
                {["#f87171", "#fb923c", "#a78bfa"].map((c, i) => (
                  <div key={i} className="w-8 h-8 rounded-full border-2 border-[#0D1B3E]" style={{ background: c }} />
                ))}
              </div>
              <div>
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />)}
                  <span className="text-white/70 text-xs ml-1">4.9/5</span>
                </div>
                <p className="text-white/50 text-xs">Loved by 2,400+ planners</p>
              </div>
            </div>

            {/* Price + CTAs */}
            <div className="space-y-4 pt-2">
              <div className="flex items-baseline gap-3 justify-center lg:justify-start">
                <span className="text-white/30 text-xl line-through font-medium">$19.99</span>
                <span className="text-white text-5xl font-black tracking-tight">$9.99</span>
                <span className="bg-green-500/20 text-green-400 text-xs font-bold px-2.5 py-1 rounded-full border border-green-500/20">SAVE 50%</span>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start">
                <Link
                  href="/checkout"
                  className="flex items-center justify-center gap-2 bg-amber-400 hover:bg-amber-300 text-[#0D1B3E] font-bold text-base px-8 py-4 rounded-xl transition-all hover:shadow-2xl hover:shadow-amber-400/25 hover:-translate-y-0.5"
                  data-testid="link-hero-checkout"
                >
                  <Download className="w-4 h-4" />
                  Get It for $9.99 — Card
                </Link>
                <Link
                  href="/checkout?tab=paypal"
                  className="flex items-center justify-center gap-2 bg-[#003087] hover:bg-[#002777] text-white font-bold text-base px-8 py-4 rounded-xl transition-all hover:-translate-y-0.5"
                  data-testid="link-hero-paypal"
                >
                  <svg viewBox="0 0 24 24" className="w-4 h-4" fill="white"><path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106z"/></svg>
                  Pay with PayPal
                </Link>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 justify-center lg:justify-start text-xs text-white/40 font-medium">
              <span className="flex items-center gap-1.5"><Lock className="w-3.5 h-3.5" /> SSL Encrypted</span>
              <span className="flex items-center gap-1.5"><Zap className="w-3.5 h-3.5" /> Instant Download</span>
              <span className="flex items-center gap-1.5"><Shield className="w-3.5 h-3.5" /> Secure Token</span>
            </div>
          </motion.div>

          {/* Right — Planner cover */}
          <motion.div
            variants={fadeUp} custom={0.2} initial="hidden" animate="visible"
            className="flex-1 w-full max-w-xs sm:max-w-sm relative"
          >
            <div className="absolute -inset-10 bg-amber-400/10 rounded-full blur-3xl" />
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-[0_40px_80px_rgba(0,0,0,0.5)] ring-1 ring-white/10">
              <PlannerCover className="w-full h-auto block" />
            </div>
            <div className="absolute -bottom-3 -right-3 bg-green-500 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg z-20 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> Instant Access
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── STATS BAR ──────────────────────────────────────────── */}
      <section className="bg-amber-400 py-10 px-5">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[
            { num: "48+", label: "Pages" },
            { num: "75", label: "Summer Challenges" },
            { num: "50", label: "Bucket List Ideas" },
            { num: "30", label: "Motivational Quotes" },
          ].map((s, i) => (
            <div key={i}>
              <div className="text-4xl md:text-5xl font-black text-[#0D1B3E]">{s.num}</div>
              <div className="text-[#0D1B3E]/70 text-xs font-bold tracking-widest uppercase mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── GALLERY ────────────────────────────────────────────── */}
      <section className="py-24 bg-gray-950 px-5 sm:px-8" id="whats-inside">
        <div className="max-w-7xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-14">
            <p className="text-amber-400 text-xs font-bold tracking-widest uppercase mb-3">What's Inside</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-white tracking-tight">Everything In One Place</h2>
            <p className="text-gray-400 mt-4 text-lg max-w-xl mx-auto">Your habits, goals, fitness, finance, and bucket list — beautifully laid out and ready to fill.</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[
              { Component: PhoneMockup, label: "Track on the go", tag: "DIGITAL" },
              { Component: NotebookMockup, label: "Plan every week", tag: "PLANNER" },
              { Component: DeskMockup, label: "Design your best summer", tag: "LIFESTYLE" },
            ].map(({ Component, label, tag }, i) => (
              <motion.div
                key={i}
                variants={fadeUp} custom={i * 0.1}
                initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-60px" }}
                className="group relative rounded-2xl overflow-hidden border border-white/5 shadow-xl"
              >
                <Component className="w-full h-auto block" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300" />
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
                  <span className="text-white font-semibold text-sm">{label}</span>
                  <span className="text-xs text-white/60 bg-white/10 px-2 py-0.5 rounded-full border border-white/10">{tag}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURES ───────────────────────────────────────────── */}
      <section className="py-24 px-5 sm:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-14">
            <p className="text-amber-500 text-xs font-bold tracking-widest uppercase mb-3">Features</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-gray-900 tracking-tight">Everything You Need This Summer</h2>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={i}
                  variants={fadeUp} custom={i * 0.05}
                  initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-40px" }}
                  className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all group"
                >
                  <div className="w-11 h-11 bg-[#0D1B3E]/5 group-hover:bg-[#0D1B3E] rounded-xl flex items-center justify-center mb-4 transition-all duration-300">
                    <Icon className="w-5 h-5 text-[#0D1B3E] group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-1.5">{feature.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{feature.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ───────────────────────────────────────── */}
      <section className="py-24 px-5 sm:px-8 bg-white">
        <div className="max-w-6xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-14">
            <p className="text-amber-500 text-xs font-bold tracking-widest uppercase mb-3">Reviews</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-gray-900 tracking-tight">Real People, Real Results</h2>
            <div className="flex items-center justify-center gap-2 mt-4">
              <Stars />
              <span className="text-gray-500 font-medium text-sm">4.9 out of 5 — 2,400+ reviews</span>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <motion.div
                key={i}
                variants={fadeUp} custom={i * 0.1}
                initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-60px" }}
                className="bg-gray-50 border border-gray-100 rounded-2xl p-7 flex flex-col gap-4"
              >
                <Stars n={t.stars} />
                <p className="text-gray-700 text-sm leading-relaxed flex-1">"{t.text}"</p>
                <div className="flex items-center gap-3 pt-2 border-t border-gray-100">
                  <div className="w-9 h-9 rounded-full bg-[#0D1B3E] flex items-center justify-center text-white text-xs font-bold shrink-0">{t.avatar}</div>
                  <div>
                    <div className="font-semibold text-gray-900 text-sm">{t.name}</div>
                    <div className="text-gray-400 text-xs">{t.handle}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRICING CTA ────────────────────────────────────────── */}
      <section className="py-24 px-5 sm:px-8 bg-[#0D1B3E] relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-amber-400/5 rounded-full blur-[100px]" />
          <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-blue-600/10 rounded-full blur-[80px]" />
        </div>

        <div className="relative z-10 max-w-2xl mx-auto text-center">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <p className="text-amber-400 text-xs font-bold tracking-widest uppercase mb-5">Limited Offer</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-white tracking-tight mb-5">Start Your Summer Transformation</h2>
            <p className="text-white/50 text-base mb-10 max-w-md mx-auto leading-relaxed">
              Includes both Standard + Premium Interactive PDF. One payment, instant download, yours forever.
            </p>

            <div className="flex items-baseline justify-center gap-4 mb-10">
              <span className="text-white/30 text-2xl line-through font-medium">$19.99</span>
              <span className="text-white text-7xl font-black tracking-tight">$9.99</span>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-6 mb-8 text-left space-y-3">
              {[
                "Standard Edition PDF (48 pages)",
                "Premium Interactive Edition PDF",
                "Habit tracker + 75 challenge prompts",
                "Fitness & finance tracking spreads",
                "50 bucket list ideas + 30 quotes",
                "Instant secure download link",
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3 text-white/80 text-sm">
                  <div className="w-5 h-5 rounded-full bg-amber-400/20 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 text-amber-400" />
                  </div>
                  {item}
                </div>
              ))}
            </div>

            <div className="flex flex-col gap-3">
              <Link
                href="/checkout"
                className="flex items-center justify-center gap-2 bg-amber-400 hover:bg-amber-300 text-[#0D1B3E] font-bold text-lg px-8 py-5 rounded-xl transition-all hover:shadow-2xl hover:shadow-amber-400/30 hover:-translate-y-0.5"
                data-testid="link-cta-checkout"
              >
                <Download className="w-5 h-5" />
                Pay with Card — $9.99
              </Link>
              <Link
                href="/checkout?tab=paypal"
                className="flex items-center justify-center gap-2 bg-[#003087] hover:bg-[#002777] text-white font-bold text-lg px-8 py-5 rounded-xl transition-all hover:-translate-y-0.5"
                data-testid="link-cta-paypal"
              >
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill="white"><path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106z"/></svg>
                Pay with PayPal
              </Link>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-6 mt-8 text-white/40 text-xs font-medium">
              <span className="flex items-center gap-1.5"><Lock className="w-3.5 h-3.5" /> SSL Encrypted</span>
              <span className="flex items-center gap-1.5"><Zap className="w-3.5 h-3.5" /> Instant Access</span>
              <span className="flex items-center gap-1.5"><Shield className="w-3.5 h-3.5" /> Secure Token Link</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── FAQ ────────────────────────────────────────────────── */}
      <section className="py-24 px-5 sm:px-8 bg-white">
        <div className="max-w-2xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-12">
            <p className="text-amber-500 text-xs font-bold tracking-widest uppercase mb-3">FAQ</p>
            <h2 className="font-display text-4xl font-bold text-gray-900 tracking-tight">Common Questions</h2>
          </motion.div>
          <FAQ />
        </div>
      </section>

      {/* ── FOOTER ─────────────────────────────────────────────── */}
      <footer className="bg-gray-950 py-14 px-5 sm:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8 pb-10 border-b border-white/5">
            <div>
              <div className="font-display font-bold text-xl text-white mb-1">nillvox</div>
              <p className="text-gray-500 text-sm">Level Up Your Summer 2026</p>
            </div>
            <div className="flex flex-wrap gap-6 text-gray-500 text-sm justify-center">
              {[
                { icon: Shield, label: "Secure Payment" },
                { icon: Zap, label: "Instant Download" },
                { icon: Lock, label: "Encrypted Links" },
                { icon: Download, label: "PDF Format" },
              ].map(({ icon: Icon, label }, i) => (
                <div key={i} className="flex items-center gap-2 hover:text-gray-300 transition-colors">
                  <Icon className="w-4 h-4" />
                  <span>{label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="pt-8 text-center text-gray-600 text-sm">
            <p>© {new Date().getFullYear()} nillvox. All rights reserved. · Digital product — no physical shipping.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
