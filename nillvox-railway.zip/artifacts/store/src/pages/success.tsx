import { useLocation } from "wouter";
import { format } from "date-fns";
import { CheckCircle, Download, AlertTriangle, Clock, Sparkles } from "lucide-react";
import { useGetDownloadInfo, getGetDownloadInfoQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import PlannerCover from "@/components/PlannerCover";

export default function Success() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const token = searchParams.get("token");

  const { data: downloadInfo, isLoading, isError } = useGetDownloadInfo(token || "", {
    query: {
      enabled: !!token,
      queryKey: getGetDownloadInfoQueryKey(token || ""),
    },
  });

  if (!token) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-slate-50">
        <Alert variant="destructive" className="max-w-md">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Invalid Link</AlertTitle>
          <AlertDescription>No download token provided. Please complete your purchase first.</AlertDescription>
        </Alert>
        <Button className="mt-4" onClick={() => window.location.href = "/"} data-testid="button-return-home">
          Return to Store
        </Button>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center space-y-4">
          <div className="w-14 h-14 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-slate-600 font-medium">Verifying your purchase…</p>
        </div>
      </div>
    );
  }

  if (isError || !downloadInfo?.valid) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-slate-50">
        <Alert variant="destructive" className="max-w-md">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Link Expired or Invalid</AlertTitle>
          <AlertDescription>
            This download link is no longer valid. Please contact support if you need help accessing your purchase.
          </AlertDescription>
        </Alert>
        <Button className="mt-4" onClick={() => window.location.href = "/"} data-testid="button-return-home-error">
          Return to Store
        </Button>
      </div>
    );
  }

  const expiryFormatted = downloadInfo.expiresAt
    ? format(new Date(downloadInfo.expiresAt), "MMM d, yyyy 'at' h:mm a")
    : "in 24 hours";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-[#0d1f3c] to-slate-900 flex flex-col items-center justify-center p-4">

      {/* Glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-teal-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative z-10 w-full max-w-lg">

        {/* Success badge */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 rounded-full bg-emerald-500/20 border-2 border-emerald-400/40 flex items-center justify-center mb-4 animate-in zoom-in duration-500">
            <CheckCircle className="w-10 h-10 text-emerald-400" />
          </div>
          <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-4 py-1.5 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-emerald-400 text-xs font-bold tracking-wide uppercase">Payment Confirmed</span>
          </div>
          <h1 className="text-3xl font-black text-white text-center tracking-tight">You're all set!</h1>
          <p className="text-slate-400 text-center mt-2 max-w-xs">
            Your <strong className="text-white">nillvox Summer 2026</strong> bundle is ready to download.
          </p>
        </div>

        {/* Download card */}
        <div className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden backdrop-blur-sm">

          {/* Planner preview strip */}
          <div className="flex gap-4 p-6 border-b border-white/10 items-center bg-white/3">
            <div className="w-16 shrink-0 rounded-xl overflow-hidden shadow-lg ring-1 ring-white/20">
              <PlannerCover className="w-full h-auto block" />
            </div>
            <div>
              <p className="text-white font-bold text-sm">nillvox — Summer 2026</p>
              <p className="text-slate-400 text-xs mt-0.5">2 editions included in your bundle</p>
              <div className="flex items-center gap-1.5 mt-2">
                <Clock className="w-3 h-3 text-slate-500" />
                <span className="text-xs text-slate-500">Links expire {expiryFormatted}</span>
              </div>
            </div>
          </div>

          {/* Download buttons */}
          <div className="p-6 space-y-3">
            <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-4">Download your files</p>

            <a
              href={`/api/downloads/${token}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 bg-teal-500 hover:bg-teal-400 text-white rounded-2xl p-4 transition-all hover:shadow-lg hover:shadow-teal-500/20 hover:-translate-y-0.5 group"
              data-testid="button-download-standard"
            >
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center shrink-0">
                <Download className="w-5 h-5" />
              </div>
              <div className="flex-1 text-left">
                <div className="font-bold text-sm">Standard Edition</div>
                <div className="text-teal-100 text-xs">48-page printable PDF planner</div>
              </div>
              <div className="text-teal-200 text-xs font-semibold bg-white/10 px-2 py-1 rounded-lg">PDF</div>
            </a>

            <a
              href={`/api/downloads/${token}/premium`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 bg-white/8 hover:bg-white/12 border border-white/15 text-white rounded-2xl p-4 transition-all hover:shadow-lg hover:-translate-y-0.5 group"
              data-testid="button-download-premium"
            >
              <div className="w-10 h-10 bg-yellow-500/20 rounded-xl flex items-center justify-center shrink-0">
                <Sparkles className="w-5 h-5 text-yellow-400" />
              </div>
              <div className="flex-1 text-left">
                <div className="font-bold text-sm flex items-center gap-2">
                  Premium Interactive Edition
                  <span className="bg-yellow-500/20 text-yellow-300 text-[10px] font-bold px-1.5 py-0.5 rounded tracking-wide">PREMIUM</span>
                </div>
                <div className="text-slate-400 text-xs">50-page dashboard, level system & navigation</div>
              </div>
              <div className="text-slate-400 text-xs font-semibold bg-white/8 px-2 py-1 rounded-lg">PDF</div>
            </a>
          </div>

          {/* Warning */}
          <div className="mx-6 mb-6 bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-amber-300 font-semibold text-sm">Save your files now</p>
              <p className="text-amber-400/80 text-xs mt-0.5">
                These download links expire on <strong className="text-amber-300">{expiryFormatted}</strong>. Download and save both PDFs to your device immediately.
              </p>
            </div>
          </div>
        </div>

        {/* Pro tip */}
        <div className="mt-6 text-center">
          <p className="text-slate-500 text-xs">
            Works in <strong className="text-slate-400">GoodNotes</strong>, <strong className="text-slate-400">Notability</strong>, or print it out.
          </p>
          <button
            onClick={() => window.location.href = "/"}
            className="mt-3 text-xs text-slate-600 hover:text-slate-400 underline underline-offset-4 transition-colors"
          >
            Return to store
          </button>
        </div>

      </div>
    </div>
  );
}
