import { Router } from "express";
import path from "path";
import fs from "fs";
import { db, downloadTokensTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { DownloadFileParams, GetDownloadInfoParams } from "@workspace/api-zod";

const router = Router();

const STANDARD_PDF = path.resolve(
  process.cwd(),
  "private",
  "Level-Up-Your-Summer-2026-Planner.pdf",
);

const PREMIUM_PDF = path.resolve(
  process.cwd(),
  "private",
  "Level-Up-Your-Summer-2026-Premium.pdf",
);

async function resolveValidToken(token: string) {
  const [record] = await db
    .select()
    .from(downloadTokensTable)
    .where(eq(downloadTokensTable.token, token));
  if (!record) return null;
  if (record.expiresAt < new Date()) return null;
  return record;
}

router.get("/downloads/:token/info", async (req, res) => {
  const parsed = GetDownloadInfoParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid token" });
    return;
  }

  const record = await resolveValidToken(parsed.data.token);
  if (!record) {
    res.status(403).json({ error: "Token not found or expired" });
    return;
  }

  res.json({
    valid: true,
    expiresAt: record.expiresAt.toISOString(),
    email: null,
  });
});

async function serveFile(
  req: any,
  res: any,
  token: string,
  filePath: string,
  filename: string,
) {
  const record = await resolveValidToken(token);
  if (!record) {
    res.status(403).json({ error: "Access denied — invalid or expired token" });
    return;
  }

  if (!fs.existsSync(filePath)) {
    req.log.error({ filePath }, "PDF file not found on server");
    res.status(500).json({ error: "File not available" });
    return;
  }

  await db
    .update(downloadTokensTable)
    .set({ usedCount: String(parseInt(record.usedCount || "0") + 1) })
    .where(eq(downloadTokensTable.token, record.token));

  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, private");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("X-Robots-Tag", "noindex, nofollow");
  res.setHeader("X-Content-Type-Options", "nosniff");

  fs.createReadStream(filePath).pipe(res);
}

router.get("/downloads/:token", async (req, res) => {
  const parsed = DownloadFileParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid token" });
    return;
  }
  await serveFile(req, res, parsed.data.token, STANDARD_PDF, "Level-Up-Your-Summer-2026-Planner.pdf");
});

router.get("/downloads/:token/premium", async (req, res) => {
  const parsed = DownloadFileParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid token" });
    return;
  }
  await serveFile(req, res, parsed.data.token, PREMIUM_PDF, "Level-Up-Your-Summer-2026-Premium-Edition.pdf");
});

export default router;
