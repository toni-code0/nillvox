import { Router, type IRouter } from "express";
import healthRouter from "./health";
import ordersRouter from "./orders";
import downloadsRouter from "./downloads";

const router: IRouter = Router();

router.use(healthRouter);
router.use(ordersRouter);
router.use(downloadsRouter);

export default router;
