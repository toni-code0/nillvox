import { Router } from "express";
import { randomUUID, randomBytes } from "crypto";
import { db, ordersTable, downloadTokensTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateOrderBody,
  ConfirmOrderBody,
  GetOrderParams,
  ConfirmOrderParams,
} from "@workspace/api-zod";
import { sendOrderConfirmationEmail } from "../lib/email";

const router = Router();

router.post("/orders", async (req, res) => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { email, paymentMethod, name } = parsed.data;
  const id = randomUUID();

  try {
    const [order] = await db
      .insert(ordersTable)
      .values({
        id,
        email,
        paymentMethod,
        name: name ?? null,
        status: "pending",
      })
      .returning();

    res.status(201).json({
      id: order.id,
      email: order.email,
      name: order.name,
      paymentMethod: order.paymentMethod,
      status: order.status,
      createdAt: order.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to create order");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/orders/:id", async (req, res) => {
  const parsed = GetOrderParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid params" });
    return;
  }

  const [order] = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.id, parsed.data.id));

  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }

  res.json({
    id: order.id,
    email: order.email,
    name: order.name,
    paymentMethod: order.paymentMethod,
    status: order.status,
    createdAt: order.createdAt.toISOString(),
  });
});

router.post("/orders/:id/confirm", async (req, res) => {
  const paramsParsed = ConfirmOrderParams.safeParse(req.params);
  const bodyParsed = ConfirmOrderBody.safeParse(req.body);

  if (!paramsParsed.success || !bodyParsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const { id } = paramsParsed.data;
  const { paypalOrderId } = bodyParsed.data;

  try {
    const [order] = await db
      .select()
      .from(ordersTable)
      .where(eq(ordersTable.id, id));

    if (!order) {
      res.status(404).json({ error: "Order not found" });
      return;
    }

    // Mark order as paid
    await db
      .update(ordersTable)
      .set({ status: "paid", paypalOrderId, updatedAt: new Date() })
      .where(eq(ordersTable.id, id));

    // Generate a unique secure download token
    const token = randomBytes(48).toString("hex");
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24h

    await db.insert(downloadTokensTable).values({
      token,
      orderId: id,
      expiresAt,
      usedCount: "0",
    });

    // Send download links to customer email (non-blocking — don't fail the order if email fails)
    const domains = process.env.REPLIT_DOMAINS?.split(",")[0];
    const baseUrl = domains
      ? `https://${domains}`
      : `http://localhost:${process.env.PORT ?? 5000}`;

    sendOrderConfirmationEmail({
      to: order.email,
      name: order.name,
      token,
      expiresAt,
      baseUrl,
    }).then((result) => {
      if ("error" in result && result.error) {
        req.log.error({ error: result.error }, "Failed to send confirmation email");
      } else {
        req.log.info({ to: order.email }, "Confirmation email sent");
      }
    }).catch((err) => {
      req.log.error({ err }, "Exception sending confirmation email");
    });

    res.json({
      token,
      expiresAt: expiresAt.toISOString(),
      downloadUrl: `/api/downloads/${token}`,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to confirm order");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
