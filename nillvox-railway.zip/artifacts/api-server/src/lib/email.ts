import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function sendOrderConfirmationEmail(opts: {
  to: string;
  name: string | null;
  token: string;
  expiresAt: Date;
  baseUrl: string;
}) {
  const { to, name, token, expiresAt, baseUrl } = opts;

  const standardUrl = `${baseUrl}/api/downloads/${token}`;
  const premiumUrl = `${baseUrl}/api/downloads/${token}/premium`;
  const expiryStr = expiresAt.toLocaleString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZoneName: "short",
  });

  const greeting = name ? `Hi ${name},` : "Hi there,";

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Your nillvox Downloads</title>
</head>
<body style="margin:0;padding:0;background:#fdf6ee;font-family:Georgia,serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#fdf6ee;padding:40px 0;">
    <tr>
      <td align="center">
        <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 16px rgba(0,0,0,0.07);">

          <!-- Header -->
          <tr>
            <td style="background:#1a1a2e;padding:32px 40px;text-align:center;">
              <p style="margin:0;font-size:22px;font-weight:bold;color:#f5c97a;letter-spacing:3px;font-family:Georgia,serif;">nillvox</p>
              <p style="margin:6px 0 0;font-size:12px;color:#aaa;letter-spacing:1px;font-family:Arial,sans-serif;">LEVEL UP YOUR SUMMER 2026</p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding:36px 40px;">
              <p style="margin:0 0 8px;font-size:15px;color:#333;font-family:Arial,sans-serif;">${greeting}</p>
              <p style="margin:0 0 24px;font-size:15px;color:#333;font-family:Arial,sans-serif;">
                Thank you for your purchase! Your <strong>Level Up Your Summer 2026</strong> PDF bundle is ready to download.
              </p>

              <!-- Standard PDF -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:16px;">
                <tr>
                  <td style="background:#fdf0dc;border-radius:8px;padding:20px 24px;">
                    <p style="margin:0 0 4px;font-size:13px;color:#888;font-family:Arial,sans-serif;letter-spacing:1px;">STANDARD EDITION</p>
                    <p style="margin:0 0 14px;font-size:16px;font-weight:bold;color:#1a1a2e;font-family:Georgia,serif;">Level Up Your Summer 2026 Planner</p>
                    <a href="${standardUrl}" style="display:inline-block;background:#1a1a2e;color:#f5c97a;text-decoration:none;padding:12px 24px;border-radius:6px;font-size:14px;font-weight:bold;font-family:Arial,sans-serif;">
                      ⬇ Download Standard PDF
                    </a>
                  </td>
                </tr>
              </table>

              <!-- Premium PDF -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
                <tr>
                  <td style="background:#fff8ec;border:2px solid #f5c97a;border-radius:8px;padding:20px 24px;">
                    <p style="margin:0 0 4px;font-size:13px;color:#c8940a;font-family:Arial,sans-serif;letter-spacing:1px;">✨ PREMIUM EDITION</p>
                    <p style="margin:0 0 14px;font-size:16px;font-weight:bold;color:#1a1a2e;font-family:Georgia,serif;">Level Up Your Summer 2026 — Premium</p>
                    <a href="${premiumUrl}" style="display:inline-block;background:#f5c97a;color:#1a1a2e;text-decoration:none;padding:12px 24px;border-radius:6px;font-size:14px;font-weight:bold;font-family:Arial,sans-serif;">
                      ⬇ Download Premium PDF
                    </a>
                  </td>
                </tr>
              </table>

              <p style="margin:0 0 8px;font-size:13px;color:#888;font-family:Arial,sans-serif;">
                ⏰ These download links expire on <strong>${expiryStr}</strong>.
              </p>
              <p style="margin:0;font-size:13px;color:#888;font-family:Arial,sans-serif;">
                If you have any issues, reply to this email and we'll help you out.
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#f7f0e6;padding:20px 40px;text-align:center;border-top:1px solid #e8dfd0;">
              <p style="margin:0;font-size:12px;color:#aaa;font-family:Arial,sans-serif;">
                © 2026 nillvox · You're receiving this because you made a purchase.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

  const fromAddress = process.env.RESEND_FROM_EMAIL ?? "onboarding@resend.dev";

  return resend.emails.send({
    from: `nillvox <${fromAddress}>`,
    to: process.env.RESEND_FROM_EMAIL ? to : (process.env.RESEND_TEST_TO ?? to),
    subject: "🌞 Your nillvox Summer 2026 Downloads Are Ready!",
    html,
  });
}
