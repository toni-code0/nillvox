import { pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const ordersTable = pgTable("orders", {
  id: varchar("id", { length: 36 }).primaryKey(),
  email: text("email").notNull(),
  name: text("name"),
  paymentMethod: text("payment_method").notNull(),
  status: text("status").notNull().default("pending"),
  paypalOrderId: text("paypal_order_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const downloadTokensTable = pgTable("download_tokens", {
  token: varchar("token", { length: 128 }).primaryKey(),
  orderId: varchar("order_id", { length: 36 })
    .notNull()
    .references(() => ordersTable.id),
  expiresAt: timestamp("expires_at").notNull(),
  usedCount: text("used_count").notNull().default("0"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({
  createdAt: true,
  updatedAt: true,
});
export const insertDownloadTokenSchema = createInsertSchema(
  downloadTokensTable,
).omit({ createdAt: true });

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
export type DownloadToken = typeof downloadTokensTable.$inferSelect;
