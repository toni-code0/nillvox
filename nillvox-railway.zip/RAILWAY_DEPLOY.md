# نشر nillvox على Railway

## الخطوات الكاملة (دقيقتان)

### 1. ارفع المشروع على GitHub

1. اذهب إلى [github.com/new](https://github.com/new)
2. أنشئ repo جديد باسم `nillvox`
3. ارفع محتوى هذا الـ ZIP:
   ```
   git init
   git add .
   git commit -m "initial"
   git remote add origin https://github.com/اسمك/nillvox.git
   git push -u origin main
   ```

### 2. أنشئ مشروعاً على Railway

1. اذهب إلى [railway.app](https://railway.app) → سجّل بـ GitHub
2. اضغط **"New Project"** → **"Deploy from GitHub repo"**
3. اختر الـ repo الذي رفعته

### 3. أضف قاعدة البيانات

1. في مشروعك على Railway → اضغط **"+ Add Service"** → **"Database"** → **"PostgreSQL"**
2. Railway سيربطها تلقائياً بمتغير `DATABASE_URL`

### 4. أضف المتغيرات البيئية

في لوحة Railway → **Variables** → أضف هذه المتغيرات:

| المتغير | القيمة |
|---------|--------|
| `NODE_ENV` | `production` |
| `RESEND_API_KEY` | مفتاح Resend الخاص بك |
| `RESEND_FROM_EMAIL` | `onboarding@resend.dev` (مؤقتاً) |

> ملاحظة: `PORT` و `DATABASE_URL` تُضاف تلقائياً من Railway — لا تلمسها.

### 5. انشر!

Railway سيبدأ البناء تلقائياً. بعد 2-3 دقائق الموقع جاهز على رابط مثل:
`https://nillvox-production.up.railway.app`

### 6. ربط دومين Cloudflare (اختياري)

1. في Railway → **Settings** → **Domains** → **"Add Custom Domain"**
2. أدخل دومينك مثل `nillvox.com`
3. Railway يعطيك CNAME record
4. اذهب إلى Cloudflare → DNS → أضف الـ CNAME
5. فعّل **Proxy (البرتقالي)** في Cloudflare لحماية إضافية

## ما يعمل تلقائياً

- ✅ الدفع بالبطاقة والـ PayPal
- ✅ توليد رابط تحميل مشفر فور الدفع
- ✅ PDF Standard + PDF Premium
- ✅ إرسال إيميل تأكيد
- ✅ قاعدة البيانات PostgreSQL
- ✅ HTTPS تلقائي

## التحديثات المستقبلية

في كل مرة تدفع تغييرات لـ GitHub، Railway يعيد النشر تلقائياً.
