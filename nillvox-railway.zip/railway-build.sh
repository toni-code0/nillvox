#!/usr/bin/env bash
set -e

echo "=== Installing dependencies ==="
pnpm install --frozen-lockfile

echo "=== Building shared libs ==="
pnpm run typecheck:libs

echo "=== Building frontend (React store) ==="
cd artifacts/store
BASE_PATH="/" pnpm run build
cd ../..

echo "=== Building backend (API server) ==="
cd artifacts/api-server
pnpm run build
cd ../..

echo "=== Running DB migrations ==="
pnpm --filter @workspace/db run push

echo "=== Build complete ==="
